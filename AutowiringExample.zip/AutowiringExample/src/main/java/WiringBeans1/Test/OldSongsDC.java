package WiringBeans1.Test;

import org.springframework.stereotype.Component;

@Component
public class OldSongsDC implements CompactDisc {

	@Override
	public void play() {
		
	System.out.println(" Playing old song 1.......");	
	}

	

	

}
