package WiringBeans1.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SonyPlayer implements CDPlayer{
	
	
	CompactDisc cd;
	
	SonyPlayer(CompactDisc cd){
		this.cd=cd;
	}

	@Override
	public void startPlayer() {
		System.out.println("Player Started...");
		cd.play();
	}

	

}
