package WiringBeans1.Test;



public interface CompactDisc {
void play();
}
