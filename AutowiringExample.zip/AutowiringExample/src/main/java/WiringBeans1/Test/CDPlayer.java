package WiringBeans1.Test;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;


public interface CDPlayer {
	
	void startPlayer();

}
